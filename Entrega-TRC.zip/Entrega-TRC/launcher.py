import subprocess

# Ejecutar generador_riggio.py
subprocess.run(["python3", "generador_riggio.py"])

# Ejecutar ejecutador.py
subprocess.run(["python3", "ejecutador.py"])

# Ejecutar conversor.py
subprocess.run(["python3", "conversor.py"])

# Ejecutar csv_total.py
subprocess.run(["python3", "generado_csv_total.py"])